from .customer_tab import CustomerTab
from .vehicle_tab import VehicleTab
from .service_tab import ServiceTab
from .purchase_tab import PurchaseTab